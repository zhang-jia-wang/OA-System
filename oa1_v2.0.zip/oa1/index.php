<?php
//确定应该名称
define('APP_NAME','Home');
define('APP_URL','http://oldcar1.com');
//确定应用路径
define('APP_PATH','./Home/');
//开启调试模式
define('APP_DEBUG',TRUE);
//引入核心文件
require './ThinkPHP/ThinkPHP.php';
?>