<?php 
 return array(
	'Title'=>'客户系统',
	'DataCache'=>'1',

);
?>