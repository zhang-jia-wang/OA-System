<?php 
 return array(
	'SHOW_PAGE_TRACE'=>false,
	'APP_STATUS'=>true,
	'USER_AUTH_SESSION'=>'600',
	'LOG_RECORD'=>true,
	'LOG_LEVEL'=>'EMERG,ALERT,CRIT,ERR',
	'URL_MODEL'=>'1',
	'URL_CASE_INSENSITIVE'=>false,
	'TOKEN_ON'=>false,
	'TOKEN_RESET'=>false,
	'DB_FIELDTYPE_CHECK'=>true,

);
?>