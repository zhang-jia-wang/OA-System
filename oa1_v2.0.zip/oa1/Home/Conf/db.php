<?php
return array(
	'DB_TYPE' => 'mysql',									//数据库类型
	'DB_HOST' => '127.0.0.1',								//数据库主机
	'DB_NAME' => 'oa1test',										//数据库名称
	'DB_USER' => 'root',									//用户名
	'DB_PWD' => '123456',										//密码
	'DB_PORT' => '3306',									//端口
	'DB_PREFIX' => 'tp_',									//表前缀
	'DB_DSN' => 'mysql://oa1test:123456@127.0.0.1:3306/oa1test',//使用DSN方式配置数据库信息
);
?>